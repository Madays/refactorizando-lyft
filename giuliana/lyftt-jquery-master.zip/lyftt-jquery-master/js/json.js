var paises =
    '[{"nombre":"Australia", "phone_code": "355", "imagen":"iconos/paises/au.png"},'+
    '{"nombre":"Canada","phone_code": "49" , "imagen": "iconos/paises/ca.png"},'+
    '{ "nombre":"China","phone_code": "210","imagen": "iconos/paises/cn.png"},'+
    '{ "nombre":"Francia","phone_code": "165","imagen": "iconos/paises/fr.png"},'+
    '{ "nombre":"India","phone_code": "217","imagen": "iconos/paises/in.png"},'+
    '{"nombre":"Japon","phone_code": "213","imagen": "iconos/paises/jp.png","letra":"K<br>L"},'+
    '{ "nombre":"Mexico","phone_code": "213","imagen": "iconos/paises/mx.png","letra":"M<br>N"},'+
    '{ "nombre":"Puerto Rico","phone_code": "213","imagen": "iconos/paises/pa.png","letra":"O<br>P"},'+
    '{ "nombre":"United Kingdom","phone_code": "213","imagen": "iconos/paises/cn.png","letra":"U<br>Z"}]';




